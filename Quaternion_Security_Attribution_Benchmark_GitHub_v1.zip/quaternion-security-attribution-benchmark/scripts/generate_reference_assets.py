#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _bootstrap(root: Path) -> None:
    source = root / "src"
    if str(source) not in sys.path:
        sys.path.insert(0, str(source))


def _asset_parser(subparsers: argparse._SubParsersAction, name: str, description: str) -> None:
    parser = subparsers.add_parser(name, description=description)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument(
        "--check",
        action="store_true",
        help="verify committed assets without changing files",
    )
    mode.add_argument(
        "--update",
        action="store_true",
        help="explicitly replace the committed reference assets",
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Explicitly update or verify frozen reference assets"
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="repository root containing configs, src, registries, and reference",
    )
    subparsers = parser.add_subparsers(dest="asset", required=True)
    _asset_parser(subparsers, "known-answers", "manage the 24 fixed known-answer cases")
    _asset_parser(subparsers, "malformed-objects", "manage canonical-parser rejection vectors")
    args = parser.parse_args()
    root = args.repo_root.resolve()
    _bootstrap(root)

    from qsa_benchmark.protocol.registry_export import (  # pylint: disable=import-outside-toplevel
        check_registry_files,
        verify_sha256sums,
        write_sha256sums,
    )
    from qsa_benchmark.validation.known_answers import (  # pylint: disable=import-outside-toplevel
        known_answer_summary,
        verify_known_answer_assets,
        write_known_answer_files,
    )
    from qsa_benchmark.validation.malformed import (  # pylint: disable=import-outside-toplevel
        malformed_object_summary,
        verify_malformed_object_assets,
        write_malformed_object_files,
    )

    errors: list[str] = []
    summary_fields: dict[str, object] = {}
    try:
        if args.update:
            errors.extend(check_registry_files(root))
            if args.asset == "malformed-objects":
                errors.extend(verify_known_answer_assets(root))
            if not errors:
                if args.asset == "known-answers":
                    write_known_answer_files(root)
                else:
                    write_malformed_object_files(root)
                write_sha256sums(root)

        if args.asset == "known-answers":
            errors.extend(verify_known_answer_assets(root))
            if not errors:
                summary_fields = known_answer_summary(root)
        else:
            errors.extend(verify_malformed_object_assets(root))
            if not errors:
                summary_fields = malformed_object_summary(root)
        errors.extend(verify_sha256sums(root))
    except Exception as exc:
        errors.append(f"{type(exc).__name__}: {exc}")

    summary = {
        "asset": args.asset,
        "errors": errors,
        "mode": "update" if args.update else "check",
        "status": "PASS" if not errors else "FAIL",
        **summary_fields,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
