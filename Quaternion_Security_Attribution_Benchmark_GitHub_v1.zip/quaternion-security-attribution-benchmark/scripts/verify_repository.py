#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _bootstrap(root: Path) -> None:
    source = root / "src"
    if str(source) not in sys.path:
        sys.path.insert(0, str(source))


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Verify the complete public computational repository"
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        help="generated verification-output directory",
    )
    tier = parser.add_mutually_exclusive_group()
    tier.add_argument(
        "--static",
        action="store_true",
        help="validate identity, environment, integrity, neutrality, schemas, and registries without running the benchmark",
    )
    tier.add_argument(
        "--full",
        action="store_true",
        help="run default verification plus two full deterministic execution trees, targeted validation, and primitive scaling",
    )
    parser.add_argument(
        "--timing",
        action="store_true",
        help="include platform-conditioned timing verification; requires --full",
    )
    parser.add_argument(
        "--environment-policy",
        choices=("exact", "packages", "report"),
        default=None,
        help="exact validates the frozen interpreter, platform, package versions, and package metadata",
    )
    args = parser.parse_args()
    if args.timing and not args.full:
        parser.error("--timing requires --full")

    root = args.repo_root.resolve()
    _bootstrap(root)
    from qsa_benchmark.validation.repository import (  # pylint: disable=import-outside-toplevel
        OUTPUT_MARKER_NAME,
        load_verification_config,
        run_repository_verification,
    )

    config = load_verification_config(root)
    mode = "static" if args.static else "timing" if args.timing else "full" if args.full else "default"
    output = (
        args.output_root.resolve()
        if args.output_root is not None
        else (root / config["default_output_root"] / mode).resolve()
    )
    environment_policy = args.environment_policy or config["default_environment_policy"]

    def progress(message: str) -> None:
        print(message, file=sys.stderr, flush=True)

    try:
        summary = run_repository_verification(
            root,
            output_root=output,
            static=bool(args.static),
            full=bool(args.full),
            timing=bool(args.timing),
            environment_policy=environment_policy,
            progress=progress,
        )
    except Exception as exc:
        message = f"{type(exc).__name__}: {exc}"
        message = message.replace(str(root), "<repository>")
        message = message.replace(str(output), "<verification-output>")
        summary = {
            "executed_tier": mode,
            "status": "FAIL",
            "exit_code": 4,
            "environment_policy": environment_policy,
            "failures": [message],
            "output_paths": ["verification_summary.json", "verification_summary.txt"],
        }
        safe_to_write = (
            not output.exists()
            or (output / OUTPUT_MARKER_NAME).is_file()
        )
        if safe_to_write:
            output.mkdir(parents=True, exist_ok=True)
            (output / "verification_summary.json").write_text(
                json.dumps(summary, indent=2, sort_keys=True, allow_nan=False) + "\n",
                encoding="utf-8",
                newline="\n",
            )
            (output / "verification_summary.txt").write_text(
                "Repository verification failed.\n" + message + "\n",
                encoding="utf-8",
                newline="\n",
            )
    print(json.dumps(summary, indent=2, sort_keys=True, allow_nan=False))
    return int(summary.get("exit_code", 4))


if __name__ == "__main__":
    raise SystemExit(main())
