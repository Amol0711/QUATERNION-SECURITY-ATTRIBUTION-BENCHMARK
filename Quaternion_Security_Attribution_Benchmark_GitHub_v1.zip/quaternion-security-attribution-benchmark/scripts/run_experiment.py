#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from qsa_benchmark.protocol.config import load_protocol_config


def invoke(root: Path, *arguments: str) -> None:
    command = [sys.executable, "-m", "qsa_benchmark.protocol.experiment", *arguments]
    subprocess.run(command, cwd=root, check=True)


def run_one(root: Path, run_root: Path, label: str, include_timing: bool) -> None:
    config = load_protocol_config()
    common = ["--repo-root", str(root), "--run-root", str(run_root), "--run-label", label]
    invoke(root, "init", *common)
    for method_id in config.methods:
        invoke(root, "differential-shard", *common, "--method", method_id)
    invoke(root, "merge-differential", *common)
    invoke(root, "leakage", *common)
    invoke(root, "attacks", *common)
    if include_timing:
        for method_id in config.methods:
            invoke(root, "timing-shard", *common, "--method", method_id)
        invoke(root, "merge-timing", *common)
        invoke(root, "cost-model", *common)


def main() -> int:
    parser = argparse.ArgumentParser(description="Execute two independent full protocol runs")
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--results-root", type=Path)
    parser.add_argument("--skip-timing", action="store_true")
    args = parser.parse_args()
    root = args.repo_root.resolve()
    results = (args.results_root or root / "results/experiment").resolve()
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ.setdefault(key, "1")
    run_one(root, results / "primary_execution", "primary_execution", not args.skip_timing)
    run_one(root, results / "independent_execution", "independent_execution", not args.skip_timing)
    if not args.skip_timing:
        invoke(root, "reconcile", "--repo-root", str(root), "--results-root", str(results))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
